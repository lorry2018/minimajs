export default class MyService {

}